// #1. 유효성 검사
//isValidComment 

const isCommentValid = validateComment ();

function addComment () {
  if(!isCommentValid) 
  
  return alert("댓글을 입력해 주세요!")
}

// #2. 댓글창 입력하면 댓글 올라오게 구현 
// pseudo code
//1. textarea (#newComment) 요소에 내용을 쓰고 
//2. 단 textarea(#newComment)에 내용이 들어가지 않는 경우에는 댓글이 입력되지 않아야 한다.
//3. 버튼을 클릭 button click event 혹은 submit을 하면 
//4  li 안에 user id 정보와 댓글 content 내용이 들어가고 
//5. ul.appendchild("li") 
//6. div.appenchild("ul") 

// const addComment = document.querySelector("#newComment");
const submitButton = documnet.querySelector("#comentSubmit");
const repleArea = document.querySelector(".commentsRepleArea");
const commentContainer= document.querySelector(".commentArea");

// addComment에 default 값이 deactived
// button click, key event 

submitButton.addEventlistener("click keyup", ()=>{ 
  const addComment = document.querySelector("#newComment");
  if (!addComment.value.length) { 
    submitButton.classList.toggle("deactived");
    submitButton.style.color ="#c4e1f";
} else submitButton.style.color="#499ee9"; 

const plusComment = document.querySelector("#newComment").value;
// 댓글이 등록 됐을 때 초기화
addComment.value = "";
// 5,6번 appendchild 대신 textContent ``으로 내용 가져옴
const addTextComment = commentContent.textcontent.split("<div>").split("/div");
commentContent.textcontent = '<div class="commentContent">'+ 
`<ul class="commentContent">
  <li class="commentId">raeng_</li>
  <li class="comment>${plusComment}</li>
</ul>
  <i class="far fa-heart"></i>` + addTextComment + '</div>'
// return plusComment; 리턴 값 필요한가 init function할 시

init();
});


//init의 기능 function init 사용법 여쭤보기


const init = function () {
  commentButton.addEventlistener("click", addComment);
}

